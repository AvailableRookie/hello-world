NCCL_SOCKET_IFNAME=en,eth,em,bond

# PROJECT_ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." && pwd )"
# export REPO_HOME="${PROJECT_ROOT}"
# echo "REPO_HOME: $REPO_HOME"

# Change the data_paths and image_folders to your own data
#data_paths="/u01/isi/nfs_data/chart/Data/CharQA/ChartQA_Dataset/train/rl_data_temp_filter_sft.jsonl" 
data_paths="/u01/isi/nfs_data/chart/math/data_process/infer/rl_formatted_data_sorted.jsonl" 


image_folders=""
model_path="/u01/isi/nfs_data/chart/LLaMA-Factory/saves/qwen2_vl-7b/math/sft/Qwen2.5-VL-7B-math_lean_1"
is_reward_customized_from_vlm_module=False
echo "data_paths: $data_paths"
echo "image_folders: $image_folders"

export EXP_NAME="Qwen2.5-VL-7B-math_lean_1" # TODO: change this to your own experiment name 
TASK_TYPE="rec"
#cd ${REPO_HOME}/src/open-r1-multimodal
cd /u01/isi/nfs_data/chart/chart2code/VLM-R1/src/open-r1-multimodal
export DEBUG_MODE="true" # Enable Debug if you want to see the rollout of model during RL

# create the run directory and log file
#mkdir -p ${REPO_HOME}/runs/${EXP_NAME}/log
mkdir /u01/isi/nfs_data/chart/chart2code/VLM-R1/runs/${EXP_NAME}
mkdir /u01/isi/nfs_data/chart/chart2code/VLM-R1/runs/${EXP_NAME}/log

#export LOG_PATH="${REPO_HOME}/runs/${EXP_NAME}/log/debug_log.$(date +%Y-%m-%d-%H-%M-%S).txt"
export LOG_PATH="/u01/isi/nfs_data/chart/chart2code/VLM-R1/runs/${EXP_NAME}/log/debug_log.$(date +%Y-%m-%d-%H-%M-%S).txt"
# MAX_STEPS=1200 # TODO: change this to your own max steps


# export WANDB_DISABLED=true
#export 
#export CUDA_VISIBLE_DEVICES=0
#CUDA_VISIBLE_DEVICES=1,3,4,5 torchrun --nproc_per_node="4"
CUDA_VISIBLE_DEVICES=4,5,6,7 torchrun --nproc_per_node="4" \
    --nnodes="1" \
    --node_rank="0" \
    --master_addr="127.0.0.1" \
    --master_port="12349" \
  src/open_r1/grpo_jsonl.py \
    --use_vllm False \
    --output_dir /u01/isi/nfs_data/chart/chart2code/VLM-R1/checkpoints/rl/${EXP_NAME} \
    --resume_from_checkpoint True \
    --model_name_or_path $model_path \
    --data_file_paths $data_paths \
    --image_folders "" \
    --is_reward_customized_from_vlm_module $is_reward_customized_from_vlm_module \
    --task_type $TASK_TYPE \
    --per_device_train_batch_size 2 \
    --gradient_accumulation_steps 2 \
    --gradient_checkpointing true \
    --logging_steps 1 \
    --num_train_epochs 2 \
    --bf16 \
    --attn_implementation flash_attention_2 \
    --run_name ${EXP_NAME} \
    --data_seed 42 \
    --save_steps 100 \
    --num_generations 8 \
    --max_completion_length 2048 \
    --reward_funcs accuracy format auxiliary_rewards\
    --beta 0 \
    --report_to wandb \
    --dataset-name this_is_not_used \
    --deepspeed /u01/isi/nfs_data/chart/chart2code/VLM-R1/src/open-r1-multimodal/local_scripts/zero3.json \

echo "Training completed for ${EXP_NAME}"
