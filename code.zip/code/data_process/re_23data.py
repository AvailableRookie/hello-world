import json

# 要匹配的关键子串
keywords = ["由（1）", "由(1)", "由（2）"]

def should_remove(conversations):
    for convo in conversations:
        if convo.get("from") == "gpt":
            value = convo.get("value", "")
            if any(keyword in value for keyword in keywords):
                return True
    return False

# 读取 JSON 文件
with open("/u01/isi/nfs_data/chart/math/data_process/sft_train_cn_no_lean.json", "r", encoding="utf-8") as f:
    data = json.load(f)


print(len(data))

# 过滤数据：只保留不包含指定关键字的项
filtered_data = [item for item in data if not should_remove(item.get("conversations", []))]

# 保存到新文件或覆盖原文件
with open("filtered_file.json", "w", encoding="utf-8") as f:
    json.dump(filtered_data, f, ensure_ascii=False, indent=2)
print(len(filtered_data))
print("处理完成，已生成 filtered_file.json")
