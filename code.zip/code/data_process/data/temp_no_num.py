import json
import re

# 读取 train.json 文件路径
with open("train.json", "r", encoding="utf-8") as f:
    train_data = json.load(f)

sft_data = []

for item in train_data:
    # 获取原始问题并去除题号（如 79． 或 79.）
    raw_question = item.get("new_question", "")
    cleaned_question = re.sub(r"^\s*\d+[．\.]\s*", "", raw_question)

    # 构建 SFT 格式
    sft_item = {
        "conversations": [
            {
                "from": "human",
                "value": "<image>"+cleaned_question
            },
            {
                "from": "gpt",
                "value": item.get("new_answer", "")
            }
        ],
        "images": item.get("question_image", "")
    }
    sft_data.append(sft_item)

# 保存为 sft_temp_train.json
with open("sft_temp_train.json", "w", encoding="utf-8") as f:
    json.dump(sft_data, f, ensure_ascii=False, indent=2)

print("✅ SFT 格式数据保存为 sft_temp_train.json（题号已去除）")
