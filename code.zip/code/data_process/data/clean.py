# import json
# import re

# def clean_question_by_repeated_number(question: str) -> str:
#     """
#     清洗 question 字段：
#     1. 提取题号（如 62.、51．、101、）
#     2. 去除题号前缀
#     3. 检测该题号是否在后文重复，若重复则截断
#     """
#     question = question.strip()
    
#     # 正则匹配题号：数字 + . ． 、 )
#     match = re.match(r"^(\d+[\.\．、)])\s*", question)
#     if not match:
#         return question  # 无题号，不处理

#     prefix = match.group(1)
#     prefix_end = match.end()
#     content = question[prefix_end:].strip()

#     # 如果题号再次在后文中出现，说明重复
#     dup_idx = content.find(prefix)
#     if dup_idx != -1:
#         return content[:dup_idx].strip()
#     else:
#         return content

# # 读取 JSON 文件
# with open("/u01/isi/nfs_data/chart/math/xyh/input.json", "r", encoding="utf-8") as f:
#     data = json.load(f)  # data 是 List[Dict]

# # 遍历并清洗
# for item in data:
#     if "question" in item and isinstance(item["question"], str):
#         original = item["question"]
#         cleaned = clean_question_by_repeated_number(original)
#         item["question"] = cleaned

# # 保存新文件
# with open("cleaned_data.json", "w", encoding="utf-8") as f:
#     json.dump(data, f, ensure_ascii=False, indent=2)

# print("✅ 所有 question 字段已清洗完毕并保存为 cleaned_data.json")
import json
import re

def truncate_repeated_question_content(question: str) -> str:
    """
    只检测并截断重复题干，不移除题号本身
    """
    question = question.strip()

    # 提取题号前缀（如 62.、51．、101、）
    match = re.match(r"^(\d+[\.\．、)])\s*", question)
    if not match:
        return question

    prefix = match.group(1)
    dup_idx = question.find(prefix, match.end())  # 查找从题号之后再次出现的题号

    if dup_idx != -1:
        return question[:dup_idx].strip()
    else:
        return question

# 读取原始 JSON 文件
with open("/u01/isi/nfs_data/chart/math/xyh/input.json", "r", encoding="utf-8") as f:
    data = json.load(f)

# 清洗并打印变化
print("\n🧹 以下是发生清洗的 question 字段：\n")
changed_count = 0

for item in data:
    if "question" in item and isinstance(item["question"], str):
        original = item["question"].strip()
        cleaned = truncate_repeated_question_content(original)

        if original != cleaned:
            changed_count += 1
            print("🔸 原始:")
            print(original)
            print("✅ 清洗后:")
            print(cleaned)
            print("-" * 50)

        item["question"] = cleaned

# 保存清洗后的文件
with open("cleaned_data.json", "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)

print(f"\n✅ 共清洗了 {changed_count} 条重复题干，结果已保存为 cleaned_data.json")

