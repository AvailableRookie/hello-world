import json
import logging
import re
from typing import List, Dict, Optional
from collections import defaultdict
import argparse

def remove_assistant_code(text: str) -> str:
    """Remove <assistant code> and <assistant code2> sections from the text."""
    # text = re.sub(r'<assistant code>.*?</assistant code>', '', text, flags=re.DOTALL)
    # text = re.sub(r'<assistant code2>.*?</assistant code2>', '', text, flags=re.DOTALL)
    text = re.sub(r"!\[@@.*?\]\(.*?\)\{.*?\}", '', text, flags=re.DOTALL)
    # text = re.sub(r'<assistant code2>.*?</assistant code2>', '', text, flags=re.DOTALL)
    text = re.sub(r'\n\s*\n', '\n', text).strip()
    return text

def extract_conclusion(prev_item: Dict) -> str:
    """Extract the key conclusion from the previous subproblem."""
    details = prev_item.get('details', '')
    sub_num = prev_item.get('sub_q_num', '')
    if prev_item.get('id') == 135 or (prev_item.get('original_num') == '74' and prev_item.get('sub_q_num') == '1'):
        return "由(1)可知$\\text{PO}\\bot$平面$\\text{ABC}$。"
    if 'sub_q_num' in prev_item and prev_item['sub_q_num'] == '1':
        if '$\\bot$' in details:
            match = re.search(r'(\$.*?\\bot.*?\$)', details)
            if match:
                return f"由({prev_item['sub_q_num']})可知{match.group(1)}。"
    return f"由({sub_num})可知相关结论。"

# def find_previous_subproblem(data_index: Dict[str, List[Dict]], current: Dict, sub_num: int) -> Optional[Dict]:
#     """Find the previous subproblem by original_num and sub_q_num."""
#     original_num = current.get('original_num')
#     if original_num not in data_index:
#         return None
#     for item in data_index[original_num]:
#         if item.get('sub_q_num') == str(sub_num):
#             return item
#     return None

def find_previous_subproblem(data_index: Dict[str, List[Dict]], current: Dict, sub_num: int) -> Optional[Dict]:
    """
    在 original_num 和 question_image 同时匹配的基础上，查找指定 sub_q_num 的前一子题。
    """
    original_num = current.get('original_num')
    question_image = current.get('question_image')
    
    if not original_num or original_num not in data_index:
        return None

    for item in data_index[original_num]:
        if (
            item.get('sub_q_num') == str(sub_num)
            and item.get('question_image') == question_image
        ):
            return item




def process_json_data(input_data: List[Dict]) -> List[Dict]:
    """Process JSON data to add new_question, new_answer, depends_on_previous, question_type, and has_assistant_line fields."""
    logging.info("开始索引数据")
    data_index = defaultdict(list)
    for item in input_data:
        data_index[item.get('original_num')].append(item)
    
    output_data = []
    
    for item in input_data:
        logging.info(f"处理 ID {item.get('id')}，original_num {item.get('original_num')}")
        new_item = item.copy()
        new_question = item.get('question', '')

        # 先删除代码
        new_answer = remove_assistant_code(item.get('details', ''))
        details = item.get('details', '')
        dependency_phrases = ['由（1）', '由（2）', '由(1)']
        sub_num = None
        for phrase in dependency_phrases:
            if phrase in details:
                sub_num = 1 if phrase in ['由（1）', '由(1)'] else 2
                break
        
        # 默认无依赖
        new_item['depends_on_previous'] = False
        if sub_num is not None:
            prev_subproblem = find_previous_subproblem(data_index, item, sub_num)
            if prev_subproblem:
                new_item['depends_on_previous'] = True
                prev_question = re.sub(r'^\d+．', '', prev_subproblem.get('question', '')).strip()

                # 先删除 代码
                prev_answer = remove_assistant_code(prev_subproblem.get('details', '').strip())
                conclusion = extract_conclusion(prev_subproblem)
                current_question = re.sub(r'^\d+．', '', item.get('question', '')).strip()
                new_question = f"{prev_question}\\n前面小题的答案：{prev_answer}\\n求{current_question}"
        
        # 添加 question_type 字段 
        question_text = item.get('question', '').lower()
        answer_text = item.get('answer', '').lower()
        if '求证' in question_text or '证明' in question_text or answer_text.startswith('(证明见解析') or '得证' in new_answer:
            new_item['question_type'] = '证明题'
        
        else:
            new_item['question_type'] = '解答题'
        
        # 添加 has_assistant_line 字段 
        #new_item['has_assistant_line'] = '<assistant code>' in details
        new_item['has_assistant_line'] = '/tancheng/weijx/COCO-MMR/Diagram/hhh' in details
        
        new_item['new_question'] = new_question
        new_item['new_answer'] = new_answer
        output_data.append(new_item)
    
    return output_data

def process_large_json_file(input_file: str, output_file: str):
    """Process a large JSON file and write results to an output file."""
    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            input_data = json.load(f)
        output_data = process_json_data(input_data)
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(output_data, f, ensure_ascii=False, indent=2)
        print(f"成功处理 {len(input_data)} 条 JSON 数据，保存至 {output_file}")
    except FileNotFoundError:
        print(f"错误：输入文件 {input_file} 未找到。")
    except json.JSONDecodeError as e:
        print(f"错误：输入文件 JSON 格式错误：{e}")
    except Exception as e:
        print(f"错误：{e}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="处理 JSON 数据以添加 new_question 和 new_answer 字段")
    parser.add_argument('--input', default="/u01/isi/nfs_data/chart/math/data_process/data/add/A_not_in_B.json", help="输入 JSON 文件路径")
    parser.add_argument('--output', default="/u01/isi/nfs_data/chart/math/data_process/data/add/A_not_in_B_data_0719.json", help="输出 JSON 文件路径")
    args = parser.parse_args()
    process_large_json_file(args.input, args.output)