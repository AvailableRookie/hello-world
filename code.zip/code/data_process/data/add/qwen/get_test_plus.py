import json

# 输入（错误项）文件路径
input_file = "/u01/isi/nfs_data/chart/math/data_process/data/add/qwen/incorrect_output.json"
# 输出文件路径（字段已清除）
output_file = "/u01/isi/nfs_data/chart/math/data_process/data/add/qwen/test_plus.json"

# 加载数据
with open(input_file, "r", encoding="utf-8") as f:
    incorrect_items = json.load(f)

# 要删除的字段
fields_to_remove = {"output", "judge_output", "score"}

# 清除字段
cleaned_items = []
for item in incorrect_items:
    cleaned_item = {k: v for k, v in item.items() if k not in fields_to_remove}
    cleaned_items.append(cleaned_item)

# 保存清洗后的数据
with open(output_file, "w", encoding="utf-8") as f:
    json.dump(cleaned_items, f, ensure_ascii=False, indent=2)

print(f"✅ 字段已清除，保存至：{output_file}")
