import json

# 读取 JSON 文件
with open('/u01/isi/nfs_data/chart/math/data_process/data/add/data_all.json', 'r', encoding='utf-8') as f:
    data_a = json.load(f)

with open('/u01/isi/nfs_data/chart/math/data_process/data/new_finall_data_040715.json', 'r', encoding='utf-8') as f:
    data_b = json.load(f)

print(len(data_a))
# 提取 B 中所有的 question 字段，用集合提高查找效率
questions_b = {item['question'] for item in data_b}

# 从 A 中筛选出不在 B 中的项
unique_a = [item for item in data_a if item['question'] not in questions_b]

# 保存筛选后的结果为新 JSON 文件
with open('A_not_in_B.json', 'w', encoding='utf-8') as f:
    json.dump(unique_a, f, ensure_ascii=False, indent=2)

# 打印长度
print("A 中不在 B 中的元素个数：", len(unique_a))
