# import json
# import random
# from collections import defaultdict
# from sklearn.model_selection import train_test_split

# # 假设你已经加载了json数据到data中
# with open("/u01/isi/nfs_data/chart/math/data_process/data/output.json", "r", encoding="utf-8") as f:
#     data = json.load(f)


# # Step 1: 分为两个子集
# has_line = [item for item in data if item.get("has_assistant_line") == True]
# no_line = [item for item in data if item.get("has_assistant_line") == False]

# # Step 2: 函数用于分层采样
# def stratified_sample(data, ratio, stratify_keys):
#     grouped = defaultdict(list)
#     for item in data:
#         key = tuple(item.get(k) for k in stratify_keys)
#         grouped[key].append(item)

#     sampled = []
#     for group_items in grouped.values():
#         k = max(1, int(len(group_items) * ratio))  # 至少抽一个
#         sampled.extend(random.sample(group_items, min(k, len(group_items))))
    
#     sampled_ids = set(item["id"] for item in sampled)
#     remaining = [item for item in data if item["id"] not in sampled_ids]
#     return sampled, remaining

# # Step 3: 抽取10%样本（尽量均衡）
# test_has_line, train_has_line = stratified_sample(
#     has_line, 0.1, ["category", "question_type", "depends_on_previous"]
# )
# test_no_line, train_no_line = stratified_sample(
#     no_line, 0.1, ["category", "question_type", "depends_on_previous"]
# )

# # Step 4: 合并结果
# train_set = train_has_line + train_no_line
# test_set = test_has_line + test_no_line

# print(len(train_set))
# print(len(test_set))

import json
import random
from collections import defaultdict, Counter
from typing import List, Dict, Tuple

# 设置随机种子
random.seed(42)

# 加载数据
with open("/u01/isi/nfs_data/chart/math/data_process/data/new_finall_data_0715.json", "r", encoding="utf-8") as f:
    data = json.load(f)

# 拆分 has_assistant_line 为 True / False
has_line = [item for item in data if item.get("has_assistant_line") is True]
no_line = [item for item in data if item.get("has_assistant_line") is False]

# 分层采样函数
def stratified_sample(
    data: List[Dict],
    ratio: float,
    stratify_keys: List[str]
) -> Tuple[List[Dict], List[Dict]]:
    grouped = defaultdict(list)
    for item in data:
        key = tuple(item.get(k) for k in stratify_keys)
        grouped[key].append(item)

    sampled = []
    for group_items in grouped.values():
        k = max(1, int(len(group_items) * ratio))
        if len(group_items) <= k:
            sampled.extend(group_items)
        else:
            sampled.extend(random.sample(group_items, k))

    sampled_ids = set(item["id"] for item in sampled)
    remaining = [item for item in data if item["id"] not in sampled_ids]
    return sampled, remaining

# 拆分
keys = ["category", "question_type", "depends_on_previous"]
test_has_line, train_has_line = stratified_sample(has_line, 0.1, keys)
test_no_line, train_no_line = stratified_sample(no_line, 0.1, keys)

# 合并训练集和测试集
train_set = train_has_line + train_no_line
test_set = test_has_line + test_no_line

# 输出统计函数
def print_stats(dataset: List[Dict], name: str):
    print(f"\n📊 {name} 集合共 {len(dataset)} 条")
    counter = Counter(
        (item["category"], item["question_type"], item["depends_on_previous"])
        for item in dataset
    )
    print(f"{'Category':<15} {'QType':<10} {'Depends':<8} Count")
    for (cat, qtype, depends), count in counter.most_common():
        print(f"{cat:<15} {qtype:<10} {str(depends):<8} {count}")

# 打印统计信息
print_stats(train_set, "训练")
print_stats(test_set, "测试")

# 可选：写入文件
# with open("train.json", "w", encoding="utf-8") as f:
#     json.dump(train_set, f, ensure_ascii=False, indent=2)

# with open("test.json", "w", encoding="utf-8") as f:
#     json.dump(test_set, f, ensure_ascii=False, indent=2)
from collections import Counter

def count_by_has_assistant_line(dataset, name):
    count_true = sum(1 for item in dataset if item.get("has_assistant_line") is True)
    count_false = sum(1 for item in dataset if item.get("has_assistant_line") is False)
    total = len(dataset)
    print(f"\n📊 {name} 集：共 {total} 条")
    print(f"  ➤ has_assistant_line=True:  {count_true}")
    print(f"  ➤ has_assistant_line=False: {count_false}")

def detailed_distribution(dataset, name):
    print(f"\n📌 {name} 集字段组合分布：")
    combo_counter = Counter(
        (item.get("has_assistant_line"),
         item.get("category"),
         item.get("question_type"),
         item.get("depends_on_previous"))
        for item in dataset
    )
    print(f"{'HasLine':<8} {'Category':<15} {'QType':<10} {'Depends':<8} Count")
    for (has_line, cat, qtype, depends), count in combo_counter.most_common():
        print(f"{str(has_line):<8} {cat:<15} {qtype:<10} {str(depends):<8} {count}")


count_by_has_assistant_line(train_set, "训练")
count_by_has_assistant_line(test_set, "测试")

detailed_distribution(train_set, "训练")
detailed_distribution(test_set, "测试")




# 可选：写入文件
with open("train.json", "w", encoding="utf-8") as f:
    json.dump(train_set, f, ensure_ascii=False, indent=2)

with open("test.json", "w", encoding="utf-8") as f:
    json.dump(test_set, f, ensure_ascii=False, indent=2)