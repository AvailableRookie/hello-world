import asyncio
import json
from tqdm import tqdm
from pathlib import Path
from openai import OpenAI
from typing import Dict

# 初始化 DeepSeek 客户端
client = OpenAI(
    api_key="sk-51abf6142f8f4a27a052af6a2d62a09e",  # ← 替换为你的 API Key
    base_url="https://api.deepseek.com"
)

# 文件路径配置
# input_file = "/u01/isi/nfs_data/chart/math/data_process/data/train.json"
# output_jsonl = "/u01/isi/nfs_data/chart/math/data_process/data/translate/train_en.jsonl"
# final_output_json = "/u01/isi/nfs_data/chart/math/data_process/data/translate/train_en.json"

# # 文件路径配置
input_file = "/u01/isi/nfs_data/chart/math/data_process/data/add/A_not_in_B_data_0719.json"
output_jsonl = "/u01/isi/nfs_data/chart/math/data_process/data/add/A_not_in_B_data_0719_en.jsonl"
final_output_json = "/u01/isi/nfs_data/chart/math/data_process/data/add/A_not_in_B_data_0719_en.json"


# 写文件锁
write_lock = asyncio.Lock()

# 优化翻译 prompt（避免破坏数学内容）
async def translate_to_english(text: str, semaphore) -> str:
    async with semaphore:
        try:
            response = client.chat.completions.create(
                model="deepseek-chat",
                messages=[
                    {"role": "system", "content": "You are a professional translator who specializes in accurately translating educational content from Chinese to English. Maintain all mathematical symbols, formulas, and technical expressions exactly as they are."},
                    {"role": "user", "content": f"""Translate the following content into English. DO NOT modify any mathematical symbols, equations, or formatting. Focus only on translating natural language content:{text}"""}
                ],
                stream=False
            )
            return response.choices[0].message.content.strip()
        except Exception as e:
            print(f"[TRANSLATION ERROR]: {e}")
            return "[TRANSLATION ERROR]"

# 处理单个样本的翻译
async def evaluate_item(item, semaphore):
    async with semaphore:
        item_id = item.get("id", "unknown")
        try:
            print(f"[INFO] Translating item: {item_id}")

            # 翻译 new_question 和 new_answer
            item["new_question_en"] = await translate_to_english(item.get("new_question", ""), semaphore)
            item["new_answer_en"] = await translate_to_english(item.get("new_answer", ""), semaphore)

        except Exception as e:
            print(f"[ERROR] Item {item_id} translation failed: {e}")
            item["new_question_en"] = "[TRANSLATION ERROR]"
            item["new_answer_en"] = "[TRANSLATION ERROR]"

        # 写入 JSONL
        async with write_lock:
            with open(output_jsonl, "a", encoding="utf-8") as f:
                f.write(json.dumps(item, ensure_ascii=False) + "\n")

# 并发处理所有数据
async def process_all(data, max_concurrent=10):
    semaphore = asyncio.Semaphore(max_concurrent)
    tasks = [evaluate_item(item, semaphore) for item in data]
    for task in tqdm(asyncio.as_completed(tasks), total=len(tasks), desc="Translating"):
        await task

# 合并 JSONL -> JSON
def jsonl_to_json(jsonl_path, json_path):
    results = []
    with open(jsonl_path, "r", encoding="utf-8") as f:
        for line in f:
            results.append(json.loads(line))
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

# 主函数
def main():
    # 确保输出目录存在
    Path(output_jsonl).parent.mkdir(parents=True, exist_ok=True)

    # 读取输入数据
    with open(input_file, "r", encoding="utf-8") as f:
        data = json.load(f)

    # 清空旧 jsonl 文件
    if Path(output_jsonl).exists():
        Path(output_jsonl).unlink()

    # 异步执行翻译任务
    asyncio.run(process_all(data, max_concurrent=10))

    # 合并输出为 JSON 文件
    jsonl_to_json(output_jsonl, final_output_json)
    print(f"\n✅ 翻译完成，结果已保存至: {final_output_json}")

if __name__ == "__main__":
    main()
