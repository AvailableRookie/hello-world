import json

# 输入输出文件路径
input_path = "/u01/isi/nfs_data/chart/math/data_process/infer/correct_num.json"
output_path = "rl_train.json"

# 读取文件
with open(input_path, "r", encoding="utf-8") as f:
    data = json.load(f)

# 筛选 correct_num 在 1 到 7 的样本，并删除指定字段
filtered_data = []
for item in data:
    if 1 <= item.get("correct_num", 0) <= 7:
        item_copy = item.copy()
        item_copy.pop("output", None)
        item_copy.pop("judge_output", None)
        item_copy.pop("score", None)
        filtered_data.append(item_copy)



# 保存为新的 JSON 文件
with open(output_path, "w", encoding="utf-8") as f:
    json.dump(filtered_data, f, ensure_ascii=False, indent=2)

print(f"筛选完成，共 {len(filtered_data)} 个样本，已保存至 {output_path}")
