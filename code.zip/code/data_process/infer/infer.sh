
/u01/isi/miniforge3/envs/openai_server/bin/python /u01/isi/nfs_data/chart/math/data_process/eval/eval_image.py \
--input_path /u01/isi/nfs_data/chart/math/data_process/data/translate/data_train_with_lean_en.json \
--output_dir /u01/isi/nfs_data/chart/math/data_process/infer/1 \
--api_key "sk-5e75860685d44576a4761abd51dc3105" \
--model qwen_2_5_vl \
--url http://localhost:6605/v1




/u01/isi/miniforge3/envs/openai_server/bin/python /u01/isi/nfs_data/chart/math/data_process/eval/eval_image.py \
--input_path /u01/isi/nfs_data/chart/math/data_process/data/translate/data_train_with_lean_en.json \
--output_dir /u01/isi/nfs_data/chart/math/data_process/infer/2 \
--api_key "sk-5e75860685d44576a4761abd51dc3105" \
--model qwen_2_5_vl \
--url http://localhost:6605/v1



/u01/isi/miniforge3/envs/openai_server/bin/python /u01/isi/nfs_data/chart/math/data_process/eval/eval_image.py \
--input_path /u01/isi/nfs_data/chart/math/data_process/data/translate/data_train_with_lean_en.json \
--output_dir /u01/isi/nfs_data/chart/math/data_process/infer/3 \
--api_key "sk-5e75860685d44576a4761abd51dc3105" \
--model qwen_2_5_vl \
--url http://localhost:6605/v1




/u01/isi/miniforge3/envs/openai_server/bin/python /u01/isi/nfs_data/chart/math/data_process/eval/eval_image.py \
--input_path /u01/isi/nfs_data/chart/math/data_process/data/translate/data_train_with_lean_en.json \
--output_dir /u01/isi/nfs_data/chart/math/data_process/infer/4 \
--api_key "sk-5e75860685d44576a4761abd51dc3105" \
--model qwen_2_5_vl \
--url http://localhost:6605/v1



/u01/isi/miniforge3/envs/openai_server/bin/python /u01/isi/nfs_data/chart/math/data_process/eval/eval_image.py \
--input_path /u01/isi/nfs_data/chart/math/data_process/data/translate/data_train_with_lean_en.json \
--output_dir /u01/isi/nfs_data/chart/math/data_process/infer/5 \
--api_key "sk-5e75860685d44576a4761abd51dc3105" \
--model qwen_2_5_vl \
--url http://localhost:6605/v1




/u01/isi/miniforge3/envs/openai_server/bin/python /u01/isi/nfs_data/chart/math/data_process/eval/eval_image.py \
--input_path /u01/isi/nfs_data/chart/math/data_process/data/translate/data_train_with_lean_en.json \
--output_dir /u01/isi/nfs_data/chart/math/data_process/infer/6 \
--api_key "sk-5e75860685d44576a4761abd51dc3105" \
--model qwen_2_5_vl \
--url http://localhost:6605/v1




/u01/isi/miniforge3/envs/openai_server/bin/python /u01/isi/nfs_data/chart/math/data_process/eval/eval_image.py \
--input_path /u01/isi/nfs_data/chart/math/data_process/data/translate/data_train_with_lean_en.json \
--output_dir /u01/isi/nfs_data/chart/math/data_process/infer/7 \
--api_key "sk-5e75860685d44576a4761abd51dc3105" \
--model qwen_2_5_vl \
--url http://localhost:6605/v1




/u01/isi/miniforge3/envs/openai_server/bin/python /u01/isi/nfs_data/chart/math/data_process/eval/eval_image.py \
--input_path /u01/isi/nfs_data/chart/math/data_process/data/translate/data_train_with_lean_en.json \
--output_dir /u01/isi/nfs_data/chart/math/data_process/infer/8 \
--api_key "sk-5e75860685d44576a4761abd51dc3105" \
--model qwen_2_5_vl \
--url http://localhost:6605/v1
