import json
from tqdm import tqdm
from pathlib import Path
from openai import OpenAI
from concurrent.futures import ThreadPoolExecutor, as_completed

# 初始化 DeepSeek 客户端
client = OpenAI(
    api_key="sk-51abf6142f8f4a27a052af6a2d62a09e",  # 替换为你的 API Key
    base_url="https://api.deepseek.com"
)

# 根目录，包含多个子文件夹，每个子文件夹里有 output.json
ROOT_DIR = Path("/u01/isi/nfs_data/chart/math/data_process/infer")

# 构造 prompt（略）

# 构造 prompt（解答题）
def build_answer_prompt(item):
    pro_prompt = f"""
The question:
{item['new_question_en']}
standard answers:
{item['answer']}
Detailed analysis:
{item['new_answer_en']}
students' answers:
{item['output']}
"""
    free_prompt = r"""
Now you are playing the role of a strict grading teacher. Your task is to review and score the students' answers based on the standard answers. Throughout the grading process, you need to be familiar with the following key points:
- Grading is only based on the final answers given by the students to determine their correctness, and it does not require checking whether the intermediate solution steps are correct.
- First, extract the final answer from the students' solutions and display it in the analysis results. Then, judge whether the answer is correct.
- Based on your analysis results, give the score. When presenting the scoring basis, you should describe it in segments according to the logic of the analysis. The summary of the scoring basis should be placed at the end, and it can be in the following format: "In conclusion, the student's answer should receive x points" (x represents the specific score of the student).
- Based on your analysis, give the score and display it in a code block in "JSON" format.
Please strictly follow the output format requirements. Your output format is:
【Grading Basis】:
【Total Score】: float
【JSON】:{
"score": float
}
The grading criteria for the exam are as follows:
【Score Ranges】: Evaluate the final answers based on the reference standard answers. There are two ranges, from high to low, which are 1 point and 0 points (0 points is the lowest. If there are situations where 0 points need to be deducted despite having 0 points, then 0 points will be given instead).
【Range Details】:
1 point:
If the final answer given by the student is consistent with the standard answer, give 1 point.
If the student's answer is mathematically equivalent to the standard answer, for example, the student's answer is 1 + 1/2x and the standard answer is 1 + 0.5x, since 1/2 = 0.5, this situation also gives 1 point.
0 points:
If the final answer given by the student is not semantically and mathematically consistent with the standard answer, give 0 points.
""" 
    return pro_prompt + "\n" + free_prompt

# 构造 prompt（证明题）
def build_proof_prompt(item):
    pro_prompt = f"""You are an expert in the scoring scheme for mathematical proof questions...
The question:
{item['new_question_en']}
The ground truth of the statement:
{item['answer']}
Detailed analysis:
{item['new_answer_en']}
The test subject’s solution:
{item['output']}
"""
    prove_prompt = """
Your task is to evaluate the quality of the proof based on five criteria and give a score between 0 and 1: logical validity (30%), completeness (20%), correctness (20%), construction of auxiliary lines (20%), and clarity (10%).
Instructions:
1. Analyze the proof step by step.
2. For each criterion:
- Logical Validity: Check if each step follows logically from the previous one. Flag any logical
errors.
- Completeness: Verify if all necessary cases and steps are included to prove the theorem.
- Correctness: Confirm if the final conclusion is correct.
- Construction of auxiliary lines: Determine whether auxiliary lines have been successfully constructed and provide the corresponding Lean4 code for the image.
- Clarity: Assess if the proof is clear, unambiguous, and well-explained.
3. Assign a sub-score (0 to 1) for each criterion and compute the total score using the weights:
(0.3 × validity) + (0.2 × completeness) + (0.2 × correctness) + (0.2 × construction) + (0.1 × clarity).
4. Provide a brief explanation (2-3 sentences) summarizing any errors or issues and justifying
the score.
Final output format:
【JSON】：
{
"score": float,
"validity": float,
"completeness": float,
"correctness": float,
"construction": float,
"clarity": float,
"explanation": str
}
"""
    return pro_prompt + "\n" + prove_prompt


# 单个样本处理函数
def evaluate_item(item):
    item_id = item.get("id", "unknown")
    try:
        if item.get("question_type") == "解答题":
            prompt = build_answer_prompt(item)
        else:
            prompt = build_proof_prompt(item)

        response = client.chat.completions.create(
            model="deepseek-chat",
            messages=[
                {"role": "system", "content": "You are a helpful assistant."},
                {"role": "user", "content": prompt}
            ],
            stream=False
        )

        item["judge_output"] = response.choices[0].message.content.strip()
    except Exception as e:
        print(f"[ERROR] Item {item_id} failed: {e}")
        item["judge_output"] = f"[ERROR] {str(e)}"
    return item

# 合并 .jsonl 到 .json
def jsonl_to_json(jsonl_path, json_path):
    results = []
    with open(jsonl_path, "r", encoding="utf-8") as f:
        for line in f:
            results.append(json.loads(line))
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

# 处理单个子文件夹
def process_folder(folder_path: Path, max_workers=30):
    input_file = folder_path / "output.json"
    output_jsonl = folder_path / "judged_output.jsonl"
    output_json = folder_path / "judged_output.json"

    if not input_file.exists():
        print(f"[WARNING] No output.json in {folder_path}, skipped.")
        return

    with open(input_file, "r", encoding="utf-8") as f:
        data = json.load(f)

    # 清空旧 jsonl
    if output_jsonl.exists():
        output_jsonl.unlink()

    with open(output_jsonl, "a", encoding="utf-8") as out_f:
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            futures = [executor.submit(evaluate_item, item) for item in data]

            for future in tqdm(as_completed(futures), total=len(futures), desc=f"Processing {folder_path.name}"):
                result = future.result()
                out_f.write(json.dumps(result, ensure_ascii=False) + "\n")

    # 合并 .jsonl 成 .json
    jsonl_to_json(output_jsonl, output_json)

    print(f"✅ Done: {folder_path.name}, saved to {output_json}")

# 主函数：处理所有子文件夹
def main():
    subfolders = [p for p in ROOT_DIR.iterdir() if p.is_dir()]

    for folder in subfolders:
        process_folder(folder, max_workers=30)

if __name__ == "__main__":
    main()