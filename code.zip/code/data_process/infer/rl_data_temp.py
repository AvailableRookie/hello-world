import json
import re

input_path = "/u01/isi/nfs_data/chart/math/data_process/infer/rl_train.json"
output_path = "rl_formatted_data_sorted.jsonl"

def remove_question_number(text):
    # 匹配开头如：84.、84．、84、、84)、84）等格式
    return re.sub(r"^\s*\d+\s*[\.\．、\)\）\-]+\s*", "", text)

# 读取数据
with open(input_path, "r", encoding="utf-8") as f:
    data = json.load(f)

# 按 correct_num 从大到小排序
sorted_data = sorted(data, key=lambda x: x.get("correct_num", 0), reverse=True)

# 写入 JSONL
with open(output_path, "w", encoding="utf-8") as f_out:
    for item in sorted_data:
        cleaned_question = remove_question_number(item["new_question_en"])
        output_item = {
            "conversations": [
                {
                    "from": "human",
                    "value": f"<image>{cleaned_question}"
                },
                {
                    "from": "gpt",
                    "value": item["new_answer_lean"]
                }
            ],
            "images": [item["question_image"]],
            "answer": item["answer"],
            "correct_num": item["correct_num"],
            "accu_reward_method": item["question_type"]
        }
        f_out.write(json.dumps(output_item, ensure_ascii=False) + "\n")

print(f"已按 correct_num 降序排序并保存为 RL 训练格式，共 {len(sorted_data)} 条，文件位于：{output_path}")
