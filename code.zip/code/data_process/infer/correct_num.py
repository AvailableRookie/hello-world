import os
import json
from collections import defaultdict

def is_correct(sample):
    if sample["question_type"] == "证明题":
        return sample["score"] > 0.8
    else:
        return sample["score"] == 1

def load_all_predictions(root_dir):
    all_samples = defaultdict(list)
    
    for subfolder in os.listdir(root_dir):
        sub_path = os.path.join(root_dir, subfolder, "scored_output.json")
        if os.path.isfile(sub_path):
            with open(sub_path, "r", encoding="utf-8") as f:
                predictions = json.load(f)
                for sample in predictions:
                    key = sample["new_answer_en"]
                    all_samples[key].append(sample)
    
    return all_samples

def aggregate_predictions(all_samples):
    result = []
    for key, sample_list in all_samples.items():
        correct_num = sum(is_correct(s) for s in sample_list)
        # 只保留一个样本（任选一个），添加 correct_num 字段
        sample = sample_list[0].copy()
        sample["correct_num"] = correct_num
        result.append(sample)
    return result

def save_result(output_path, result_data):
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(result_data, f, ensure_ascii=False, indent=2)

# ==== 配置路径 ====
root_folder = "/u01/isi/nfs_data/chart/math/data_process/infer"  # 替换为包含子文件夹的主目录
output_json = "correct_num.json"

# ==== 执行流程 ====
all_samples = load_all_predictions(root_folder)
aggregated = aggregate_predictions(all_samples)
save_result(output_json, aggregated)

print(f"汇总完成，共 {len(aggregated)} 个样本，结果已保存到 {output_json}")
