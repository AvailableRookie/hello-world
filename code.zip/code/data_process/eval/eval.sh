
/u01/isi/miniforge3/envs/openai_server/bin/python /u01/isi/nfs_data/chart/math/data_process/eval/eval_image.py \
--input_path /u01/isi/nfs_data/chart/math/data_process/data/add/qwen/test_plus.json \
--output_dir /u01/isi/nfs_data/chart/math/data_process/data/add/our_en_lean1 \
--api_key "sk-5e75860685d44576a4761abd51dc3105" \
--model qwen_2_5_vl \
--url http://localhost:6605/v1

