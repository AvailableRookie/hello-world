import json
import re

input_file = "/u01/isi/nfs_data/chart/math/data_process/infer/8/judged_output.json"
output_file = "/u01/isi/nfs_data/chart/math/data_process/infer/8/scored_output.json"

# 加载数据
with open(input_file, "r", encoding="utf-8") as f:
    data = json.load(f)

score_extract_fail_count = 0

# 正则表达式
proof_score_pattern = re.compile(
    r'\"score\"\s*:\s*([0-9.]+)', re.IGNORECASE
)

answer_score_pattern = re.compile(
    r'【Total Score】\s*[:：]?\s*([0-9.]+)', re.IGNORECASE
)

# 遍历数据
for item in data:
    output = item.get("judge_output", "")
    q_type = item.get("question_type", "")
    score = -1  # 默认失败为 -1

    try:
        if q_type == "证明题":
            match = proof_score_pattern.search(output)
        elif q_type == "解答题":
            match = answer_score_pattern.search(output)
        else:
            match = None

        if match:
            score = float(match.group(1))
        else:
            score_extract_fail_count += 1

    except Exception:
        score_extract_fail_count += 1
        score = -1

    item["score"] = score

# 保存结果
with open(output_file, "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)

print(f"✅ 提取完成，失败数量: {score_extract_fail_count}")
print(f"✅ 结果保存至: {output_file}")
