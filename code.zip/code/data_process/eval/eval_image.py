import os
import json
import base64
import argparse
import logging
from tqdm import tqdm
from openai import OpenAI
from concurrent.futures import ThreadPoolExecutor, as_completed

def image2base64(image_path):
    with open(image_path, 'rb') as f:
        image = f.read()
    return base64.b64encode(image).decode()

def predict(question, image_path, model, url, api_key):
    ext = os.path.splitext(image_path)[-1].lower()
    if ext not in ['.png', '.jpg', '.jpeg']:
        raise ValueError(f"Invalid image format: {ext}. Supported formats: png, jpg, jpeg")
    image_base64 = f"data:image/{ext.replace('.', '')};base64,{image2base64(image_path)}"

    client = OpenAI(
        base_url=url,
        api_key=api_key,
    )

    content = [
        {"type": "text", "text": question},
        {"type": "image_url", "image_url": {"url": image_base64}}
    ]

    messages = [{"role": "user", "content": content}]
    completion = client.chat.completions.create(
        model=model,
        messages=messages,
        temperature=0.0
    )
    return completion.choices[0].message.content

def read_json(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        return json.load(f)

def append_jsonl(file_path, data):
    with open(file_path, 'a', encoding='utf-8') as f:
        f.write(json.dumps(data, ensure_ascii=False) + '\n')

def read_jsonl(file_path):
    with open(file_path, 'r', encoding='utf-8') as f:
        return [json.loads(line) for line in f]

def jsonl2json(jsonl_path, json_path):
    data = read_jsonl(jsonl_path)
    with open(json_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def process_item(item, model, url, api_key, jsonl_path):
    try:
        question = item['new_question_en']
        image_path = item['question_image']
        result = predict(question, image_path, model, url, api_key)
        item['output'] = result
        append_jsonl(jsonl_path, item)
        return item
    except Exception as e:
        logging.error(f"ID: {item.get('id', 'unknown')} Error: {e}")
        return None

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--input_path', type=str, required=True)
    parser.add_argument('--output_dir', type=str, required=True)
    parser.add_argument('--model', type=str, required=True)
    parser.add_argument('--url', type=str, required=True)
    parser.add_argument('--api_key', type=str, required=True)
    parser.add_argument('--max_workers', type=int, default=10)
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    jsonl_path = os.path.join(args.output_dir, 'output.jsonl')
    json_path = os.path.join(args.output_dir, 'output.json')
    log_path = os.path.join(args.output_dir, 'process.log')

    logging.basicConfig(filename=log_path, level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

    input_data = read_json(args.input_path)
    processed_items = set()
    if os.path.exists(jsonl_path):
        processed_items = {json.dumps(item, sort_keys=True) for item in read_jsonl(jsonl_path)}

    with ThreadPoolExecutor(max_workers=args.max_workers) as executor:
        futures = []
        for item in input_data:
            if json.dumps(item, sort_keys=True) in processed_items:
                continue
            futures.append(executor.submit(process_item, item, args.model, args.url, args.api_key, jsonl_path))

        for future in tqdm(as_completed(futures), total=len(futures)):
            future.result()

    jsonl2json(jsonl_path, json_path)
    print(f"Processing complete. Output saved to: {json_path}")
