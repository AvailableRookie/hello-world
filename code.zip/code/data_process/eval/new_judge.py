import asyncio
import json
from tqdm import tqdm
from pathlib import Path
from openai import OpenAI
from typing import Dict

# 初始化 DeepSeek 客户端
client = OpenAI(
    api_key="sk-51abf6142f8f4a27a052af6a2d62a09e",  # 请替换为你的真实 API Key
    base_url="https://api.deepseek.com"
)

# # 文件路径配置
# input_file = "/u01/isi/nfs_data/chart/math/data_process/eval/output/our_04717/output.json"
# output_jsonl = "/u01/isi/nfs_data/chart/math/data_process/eval/judge_score/our_04717/judged_output.jsonl"
# final_output_json = "/u01/isi/nfs_data/chart/math/data_process/eval/judge_score/our_04717/judged_output.json"
# 文件路径
input_file = "/u01/isi/nfs_data/chart/math/data_process/eval/output/qwen2.5vl_en/output.json"
output_jsonl = "/u01/isi/nfs_data/chart/math/data_process/eval/judge_score/qwen2.5vl_en/judged_output.jsonl"
final_output_json = "/u01/isi/nfs_data/chart/math/data_process/eval/judge_score/qwen2.5vl_en/judged_output.json"


# 写文件锁
write_lock = asyncio.Lock()

# 构造 prompt（解答题）
def build_answer_prompt(item: Dict):
    pro_prompt = f"""
The question:
{item['new_question_en']}
standard answers:
{item['answer']}
Detailed analysis:
{item['new_answer_en']}
students' answers:
{item['output']}
"""
    free_prompt = r"""
Now you are playing the role of a strict grading teacher. Your task is to review and score the students' answers based on the standard answers. Throughout the grading process, you need to be familiar with the following key points:
- Grading is only based on the final answers given by the students to determine their correctness, and it does not require checking whether the intermediate solution steps are correct.
- First, extract the final answer from the students' solutions and display it in the analysis results. Then, judge whether the answer is correct.
- Based on your analysis results, give the score. When presenting the scoring basis, you should describe it in segments according to the logic of the analysis. The summary of the scoring basis should be placed at the end, and it can be in the following format: "In conclusion, the student's answer should receive x points" (x represents the specific score of the student).
- Based on your analysis, give the score and display it in a code block in "JSON" format.
Please strictly follow the output format requirements. Your output format is:
【Grading Basis】:
【Total Score】: float
【JSON】:{
"score": float
}
The grading criteria for the exam are as follows:
【Score Ranges】: Evaluate the final answers based on the reference standard answers. There are two ranges, from high to low, which are 1 point and 0 points (0 points is the lowest. If there are situations where 0 points need to be deducted despite having 0 points, then 0 points will be given instead).
【Range Details】:
1 point:
If the final answer given by the student is consistent with the standard answer, give 1 point.
If the student's answer is mathematically equivalent to the standard answer, for example, the student's answer is 1 + 1/2x and the standard answer is 1 + 0.5x, since 1/2 = 0.5, this situation also gives 1 point.
0 points:
If the final answer given by the student is not semantically and mathematically consistent with the standard answer, give 0 points.
""" 
    return pro_prompt + "\n" + free_prompt

# 构造 prompt（证明题）
def build_proof_prompt(item: Dict):
    pro_prompt = f"""You are an expert in the scoring scheme for mathematical proof questions...
The question:
{item['new_question_en']}
The ground truth of the statement:
{item['answer']}
Detailed analysis:
{item['new_answer_en']}
The test subject’s solution:
{item['output']}
"""
    prove_prompt = """
Your task is to evaluate the quality of the proof based on five criteria and give a score between 0 and 1: logical validity (30%), completeness (20%), correctness (20%), construction of auxiliary lines (20%), and clarity (10%).
Instructions:
1. Analyze the proof step by step.
2. For each criterion:
- Logical Validity: Check if each step follows logically from the previous one. Flag any logical
errors.
- Completeness: Verify if all necessary cases and steps are included to prove the theorem.
- Correctness: Confirm if the final conclusion is correct.
- Construction of auxiliary lines: Determine whether auxiliary lines have been successfully constructed and provide the corresponding Lean4 code for the image.
- Clarity: Assess if the proof is clear, unambiguous, and well-explained.
3. Assign a sub-score (0 to 1) for each criterion and compute the total score using the weights:
(0.3 × validity) + (0.2 × completeness) + (0.2 × correctness) + (0.2 × construction) + (0.1 × clarity).
4. Provide a brief explanation (2-3 sentences) summarizing any errors or issues and justifying
the score.
Final output format:
【JSON】：
{
"score": float,
"validity": float,
"completeness": float,
"correctness": float,
"construction": float,
"clarity": float,
"explanation": str
}
"""
    return pro_prompt + "\n" + prove_prompt

# 单个样本的评估处理
async def evaluate_item(item, semaphore):
    async with semaphore:
        item_id = item.get("id", "unknown")
        try:
            print(f"[INFO] Processing item: {item_id}")
            if item.get("question_type") == "解答题":
                prompt = build_answer_prompt(item)
            else:
                prompt = build_proof_prompt(item)

            response = client.chat.completions.create(
                model="deepseek-chat",
                messages=[
                    {"role": "system", "content": "You are a helpful assistant."},
                    {"role": "user", "content": prompt}
                ],
                stream=False
            )

            item["judge_output"] = response.choices[0].message.content.strip()

        except Exception as e:
            print(f"[ERROR] Item {item_id} failed: {e}")
            item["judge_output"] = f"[ERROR] {str(e)}"

        async with write_lock:
            with open(output_jsonl, "a", encoding="utf-8") as f:
                f.write(json.dumps(item, ensure_ascii=False) + "\n")

# 并发处理所有数据
async def process_all(data, max_concurrent=10):
    semaphore = asyncio.Semaphore(max_concurrent)
    tasks = [evaluate_item(item, semaphore) for item in data]
    for task in tqdm(asyncio.as_completed(tasks), total=len(tasks), desc="Evaluating"):
        await task

# 合并 jsonl -> json
def jsonl_to_json(jsonl_path, json_path):
    results = []
    with open(jsonl_path, "r", encoding="utf-8") as f:
        for line in f:
            results.append(json.loads(line))
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(results, f, ensure_ascii=False, indent=2)

# 主函数
def main():
    # 确保输出目录存在
    Path(output_jsonl).parent.mkdir(parents=True, exist_ok=True)

    # 读取输入数据
    with open(input_file, "r", encoding="utf-8") as f:
        data = json.load(f)

    # 清空旧 jsonl 文件
    if Path(output_jsonl).exists():
        Path(output_jsonl).unlink()

    # 异步执行
    asyncio.run(process_all(data, max_concurrent=30))

    # 合并输出
    jsonl_to_json(output_jsonl, final_output_json)
    print(f"\n✅ 评估完成，输出保存至: {final_output_json}")

if __name__ == "__main__":
    main()
