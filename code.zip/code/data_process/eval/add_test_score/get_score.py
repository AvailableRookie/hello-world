import json

# 输入文件路径
input_file = "/u01/isi/nfs_data/chart/math/data_process/data/add/our_en_lean1/correct_output_test_plus.json"

# 加载数据
with open(input_file, "r", encoding="utf-8") as f:
    data = json.load(f)


# 输入文件路径
input_file = "/u01/isi/nfs_data/chart/math/data_process/data/add/our_en_lean1/correct_output_test_plus.json"

# 加载数据
with open(input_file, "r", encoding="utf-8") as f:
    data = json.load(f)

# 初始化分类容器
categories = {
    "证明题_需要辅助线": {"total": 0, "correct": 0, "score_sum": 0.0},
    "证明题_无需辅助线": {"total": 0, "correct": 0, "score_sum": 0.0},
    "解答题_需要辅助线": {"total": 0, "correct": 0, "score_sum": 0.0},
    "解答题_无需辅助线": {"total": 0, "correct": 0, "score_sum": 0.0}
}

# 分类逻辑
for item in data:
    q_type = item.get("question_type", "")
    has_line = item.get("has_assistant_line", None)
    score = item.get("score", -1)

    # 判断分类键
    if q_type == "证明题":
        if has_line:
            key = "证明题_需要辅助线"
        else:
            key = "证明题_无需辅助线"
        is_correct = score >= 0.8
    else:  # 解答题
        if has_line:
            key = "解答题_需要辅助线"
        else:
            key = "解答题_无需辅助线"
        is_correct = score == 1.0

    categories[key]["total"] += 1
    categories[key]["score_sum"] += score if score >= 0 else 0
    if is_correct:
        categories[key]["correct"] += 1

# 输出统计结果
print("📊 各类别分数统计如下：\n")
for key, value in categories.items():
    total = value["total"]
    correct = value["correct"]
    score_sum = value["score_sum"]
    acc = correct / total if total > 0 else 0
    avg_score = score_sum / total if total > 0 else 0
    print(f"{key}:")
    print(f"  总数：{total}")
    print(f"  正确数：{correct}")
    print(f"  平均得分：{avg_score:.2f}")
    print(f"  正确率：{acc:.2%}\n")
