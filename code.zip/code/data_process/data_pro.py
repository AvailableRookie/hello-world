import json

input_path = "/u01/isi/nfs_data/chart/math/math_github/result_process/sft_train_cn_no_lean.json"   # 已替换路径的 SFT 格式输入文件
output_path = "sft_train_cn_no_lean.json"    # 转换后输出路径

# 固定的 system 描述文本
# system_text = (
#     "A conversation between User and Assistant. The user asks a question, and the Assistant solves it. "
#     "The assistant first thinks about the reasoning process in the mind and then provides the user with the answer. "
#     "The reasoning process and answer are enclosed within <think> </think> and <answer> </answer> tags, respectively, "
#     "i.e., <think> reasoning process here </think> <answer> Please put your final answer within \\boxed{} </answer>."
# )

def convert_to_conversations(entry):
    conversations = []
    for msg in entry.get("messages", []):
        role = msg.get("role")
        content = msg.get("content", "")
        if role == "user":
            conversations.append({"from": "human", "value": content})
        elif role == "assistant":
            conversations.append({"from": "gpt", "value": content})
    return {
        "conversations": conversations,
        "images": entry.get("images", []),
    }

# 读取输入文件
with open(input_path, "r", encoding="utf-8") as f:
    data = json.load(f)

# 支持输入是 list 或单条
if isinstance(data, list):
    converted = [convert_to_conversations(item) for item in data]
else:
    converted = convert_to_conversations(data)

# 保存输出
with open(output_path, "w", encoding="utf-8") as f:
    json.dump(converted, f, indent=2, ensure_ascii=False)

print(f"转换完成，输出文件保存至 {output_path}")
